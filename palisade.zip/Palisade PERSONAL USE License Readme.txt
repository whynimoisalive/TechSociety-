This " Palisade " font is for PERSONAL USE LICENSE ONLY!!
NOT FOR COMMERCIAL LICENSE, NOT FOR CORPORATE LICENSE, NOT FOR EXTENDED, ETC.

----------------------------------------
If you make my font for-profit projects, You can buy it by contacting me by email: aveniyuanita.fontdesigner@gmail.com (custom license)

For commercial use license, web license, or e-pub license & app license, you can buy my fonts at the following link:
- https://creativemarket.com/avenilettertype/291184997-Palisade-Handwritten
- https://fontbundles.net/aveni-letter-type/5317775-palisade-handwritten

To get more products visit this link :
-https://creativemarket.com/avenilettertype?page=1
- https://fontbundles.net/aveni-letter-type

Bahasa Indonesia :
Font "Palisade" yang Anda download disini hanya untuk LISENSI PENGGUNAAN PRIBADI!!
TIDAK UNTUK LISENSI KOMERSIAL (TIDAK UNTUK KEGIATAN KOMERSIAL APAPUN ITU),
TIDAK UNTUK LISENSI PERUSAHAAN, Dan Sebagainya. (Termasuk Penggunaan Dalam LABEL / THUMBNAIL YOUTUBE / LABEL MUSIC DILARANG KERAS).

Mohon dipahami dan mengerti apa itu LISENSI HAK PENGGUNAAN sebelum menggunakan font ini, 
jika ketahuan menggunakan font ini tanpa izin pemilik, anda akan dikenakan denda $5,000 / se – harga Corporate License

Jika anda membutuhkan font ini untuk kegiatan komersial bisa membeli di tautan ini :
- https://creativemarket.com/avenilettertype/291184997-Palisade-Handwritten
- https://fontbundles.net/aveni-letter-type/5317775-palisade-handwritten

Atau anda membutuhkan lisensi lainnya atau untuk penggunaan perusahaan atau lisensi hak penyiaran di YouTube
atau bisa di sebut BROADCAST LICENSE bisa menghubungi saya di e-mail : aveniyuanita.fontdesigner@gmail.com